This is EC2. This is test. Pulled from: https://gist.github.com/jsuwo/9038610#file-testbankaccount-java
